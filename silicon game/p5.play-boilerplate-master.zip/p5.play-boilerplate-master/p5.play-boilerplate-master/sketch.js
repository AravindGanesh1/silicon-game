const Engine=Matter.Engine;
const World=Matter.World;
const Bodies=Matter.Bodies;

var boyImage,boy;
var boyBackImage;
var villanImage,villan;
var zombieImage,zombie;
var treasureImage,treasure;
var backgroundImg;
var invisbleground,ground;
var background1;
var bottomPlatform,sidePlatform,upperPlatform;
var engine,world
var b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
var b11,b12,b13,b14,b15,b16,b17,b18,b19,b20;
var door,doorImage;

function preload(){
boyImage= loadAnimation("assets/boy1.png","assets/boy3.png","assets/boy2.png","assets/boy4.png");
boyBackImage= loadAnimation("assets/boy1back.png","assets/boy2back.png","assets/boy3back.png","assets/boy4back.png")
villanImage= loadAnimation("assets/villan1.png","assets/villan2.png","assets/villan3.png")
zombieImage= loadAnimation("assets/zombie1.png","assets/zombie2.png","assets/zombie3.png","assets/zombie4.png","assets/zombie5.png","assets/zombie6.png")
treasureImage= loadImage("assets/treasure.png");
backgroundImg=loadImage("assets/background gif.gif");
doorImage=loadImage("assets/portal.png")
}
function setup(){
createCanvas(windowWidth,windowHeight);
engine=Engine.create();
world=engine.world;

b1=new Box(250,600,200,20)
b2=new Box(160,490,20,200)
b3=new Box(250,700,200,20)
b4=new Box(400,700,200,20)
b5=new Box(500,600,20,200)
b6=new Box(390,500,200,20)
//b7=new Box(250,400,200,20)
//b8=new Box(400,400,200,20)
b9=new Box(550,400,200,20)
b10=new Box(650,500,20,200)
b11=new Box(700,400,200,20)
b12=new Box(600,700,200,20)
b13=new Box(700,700,200,20)
b14=new Box(850,700,200,20)
b15=new Box(800,600,20,200)
b16=new Box(870,400,200,20)
b17=new Box(970,490,20,200)


boy=createSprite(100,650,50,50);
boy.addAnimation("running",boyImage);
boy.scale=0.8;
boy.addAnimation("back",boyBackImage);

door=createSprite(width-80,60,50,50)
door.addImage(doorImage);
door.scale=0.3

zombie=createSprite(220,400,50,50)
zombie.addAnimation("zombie",zombieImage)
/*villan=createSprite(1500,650,50,50);
villan.addAnimation("running",villanImage);
villan.scale=1.2;

zombie=createSprite(1400,650,50,50);
zombie.addAnimation("runnning",zombieImage);
zombie.scale=1.1;

treasure=createSprite(1450,100,50,50);
treasure.addImage("treasure",treasureImage);
treasure.scale=0.3;*/

invisibleGround = createSprite(200,725,windowWidth,10);
invisibleGround.visible = false;




}
function draw(){
    background(backgroundImg,windowWidth,windowHeight);
    Engine.update(engine);
    b1.display();
    b2.display();
    b3.display();
    b4.display();
    b5.display();
    b6.display();
    ///b7.display();
    //b8.display();
    b9.display();
    b10.display();
    b11.display();
    b12.display();
    b13.display();
    b14.display();
    b15.display();
    b16.display();
    b17.display();
   
if(boy.isTouching(door)){
  levelUp();
}

if(boy.isTouching(zombie)){
gameOver();
}
    
  playerMovement();
  drawSprites();
}

function playerMovement(){
  if (keyDown("right_arrow")) {
  boy.x=boy.x+10;
  
  }
  if (keyDown("left_arrow")) {
    boy.x=boy.x-10;
    boy.changeAnimation("back")
    }
    if (keyDown("up_arrow")) {
        boy.y=boy.y-10;
        
        }

       
  boy.collide(invisibleGround);
  if (keyDown("down_arrow")) {
    boy.y=boy.y+10;
    
    }
   
boy.collide(invisibleGround);
  }
  function levelUp() {
    swal({
      title: `Congratulations`,
      text: "Level 1 Completed !!!",
      imageUrl:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQRuVqyj0MfAzU2G0Eyx3JgtTdrJgAhO_agRbu6Xsc5YCL7_l24jE6G2xzhSbc344XpZ_g&usqp=CAU",
      imageSize: "100x100",
      confirmButtonText: "Next Level"
    });
  }
  function gameOver() {
    swal({
      title: `OOpps !`,
      text: "Try Again ",
      imageUrl:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQRuVqyj0MfAzU2G0Eyx3JgtTdrJgAhO_agRbu6Xsc5YCL7_l24jE6G2xzhSbc344XpZ_g&usqp=CAU",
      imageSize: "100x100",
      confirmButtonText: "Thanks for Playing"
    });
  }
  


